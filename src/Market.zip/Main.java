import java.util.ArrayList;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static ArrayList<Customer> customerList;
    static ArrayList<Item> itemList;
    static ArrayList<ItemLine> itemlineList;
    static Scanner scanner;
    static boolean run;
    public static void main(String[] args) {
        customerList = new ArrayList<>();
        itemList = new ArrayList<>();
        itemlineList = new ArrayList<>();
        scanner = new Scanner(System.in);
        run = true;
        while (run == true) {
            doOperation();
            System.out.println("");
        }
    }
    static void doOperation() {
        System.out.println("Select opertaion:");

        System.out.println("1:exit");

        System.out.println("2:customer");

        System.out.println("3:order");

        System.out.println("4:item");

        System.out.println("5:item line");

        System.out.println("6:print-all");

        String ans = scanner.next();
        if (ans.equals("1") {
            run = false;
        }
        if (ans.equals("2")) {
            customerOperation();
        }
        if (ans.equals("3")) {
            orderOperation();
        }
        if (ans.equals("4")) {
            itemOperation();
        }
        if (ans.equals("5")) {
            itemLineOperation();
        }
        if (ans.equals("6")) {
            print();
        }
    }
    static void customerOperation() {
        System.out.println("Select operation:");
        System.out.println("1:Add");
        System.out.println("2:Rename");
        System.out.println("3:Remove");
        System.out.println("Print");

        String ans = scanner.next();
        if (ans.equals("1")) {
            addCustomer();
        }
        if (ans.equals("2")) {
            renameCustomer();
        }
        if (ans.equals("3")) {
            removeCustomer();
        }
        if (ans.equals("4")) {
            printCustomers();
        }
    }
    static void orderOperation() {
        System.out.println("Select operation:");
        System.out.println("1:Add");
        System.out.println("2:Add item line");
        System.out.println("3:Get total");

        String ans = scanner.next();
        if (ans.equals("1")) {
            addorder();
        }
        if (ans.equals("2")) {
            addItemLine();
        }
        if (ans.equals("3")) {
            getTotal();
        }
    }
    static void itemOperation() {
        System.out.println("Select operation:");
        System.out.println("1:Add");
        System.out.println("2:Rename");
        System.out.println("3:Remove");
        System.out.println("Print");

        String ans = scanner.next();
        if (ans.equals("1")) {
            addItem();
        }
        if (ans.equals("2")) {
            renameItem();
        }
        if (ans.equals("3")) {
            removeItem();
        }
        if (ans.equals("4")) {
            printItems();
        }
    }
    static void itemLineOperation() {
        System.out.println("Select operation:");
        System.out.println("2:Rename");
        System.out.println("3:Remove");
        System.out.println("Print");

        String ans = scanner.next();
        if (ans.equals("1")) {
            renameItemLine();
        }
        if (ans.equals("2")) {
            removeItemLine();
        }
        if (ans.equals("3")) {
            printItemLines();
        }
    }

    static void addCustomer() {
        Customer customer = new Customer();
        customer.assignNewId();
        customer.fillName();
        customer.fillAdress();
        customerList.add(customer);
    }
    static void renameCustomer() {
        printCustomers();
        Customer customer = getCustomer();
        if (customer == null) {
            return;
        }
        customer.fillName();
        customer.fillAdress();
    }
    static void removeCustomer() {
        printCustomers();
        Customer customer = getCustomer();
        if (customer == null) {
            return;
        }
        customerList.remove(customer);
    }

    static void addorder() {
        Order order = new Order();
        order.assignNewId();

        printCustomers();
        Customer customer = getCustomer();
        if (customer == null) {
            return;
        }
        printItems();
        Item item = getItem();
        if (item == null) {
            return;
        }

        order.customer = customer;
        customer.orderList.add(order);
        order.item = item;
        item.fillName();
        item.fillPrice();
    }
    static void addItemLine() {
        ItemLine itemline = new Itemline();
        itemline.assignNewId();
        itemline.fillCount();
        itemlinelist.add(itemline);
    }
    static void getTotal() {
        System.out.println("Enter order ID:");
        Scanner scanner = new Scanner(System.in);
        Integer orderId = scanner.nextInt();
        for (int i = 0; i < orderList.size(); i++) {
            Order order = orderList.get(i);
            if (order.id.equals(orderId)) {
                return order;
            }
        }
        return null;
    }

    static void addItem() {
        Item item = new Item();
        item.assignNewId();
        item.fillName();
        itemList.add(Item);
    }
    static void renameItem() {
        printItems();
        Item item = getItem();
        if (item == null) {
            return;
        }
        item.fillName();
    }
    static void removeItem() {
        printItems();
        Item item = getItem();
        if (item == null) {
            return;
        }
        itemList.remove(Item);
    }

    static void renameItemLine() {
    printItemLines();
    ItemLine itemline = getItemLine();
    if (itemline == null) {
        return;
    }
    itemline.fillCount();
}
    static void removeItemLine() {
    printItemlines();
    ItemLine itemline = getItemLine();
    if (itemline == null) {
        return;
    }
    itemlinelist.remove(Itemline);
}

    static void print() {
        printCustomers();
        printItems();
        printItemLines();
    }
    static void printCustomers() {
        System.out.println("Customers:");
        for (int i = 0; i < customerList.size(); i++) {
            Customer customer = customerList.get(i);
            customer.print();
            customer.printChecks();
        }
    }
    static void printItems() {
            System.out.println("Items:");
            for (int i = 0; i < itemList.size(); i++) {
                Item item = itemList.get(i);
                item.print();
    }
 }
    static void printItemLines() {
     System.out.println("ItemLines:");
     for (int i = 0; i < itemlineList.size(); i++) {
         ItemLine itemLine = itemlineList.get(i);
         itemLine.print();
     }
   }

    static Customer getCustomer() {
        System.out.println("Enter customer ID:");
        Integer customerId = scanner.nextInt();
        for (int i = 0; i < customerList.size(); i++) {
            Customer customer = customerList.get(i);
            if (customer.id.equals(customerId)) {
                return customer;
            }
        }
        System.out.println("Customer not found");
        return null;
    }
    static Item getItem() {
        System.out.println("Enter Item ID:");
        Integer itemId = scanner.nextInt();
        for (int i = 0; i < itemList.size(); i++) {
            Item item = itemList.get(i);
            if (Item.id.equals(itemId)) {
                return item;
            }
        }
        System.out.println("Item not found");
        return null;
    }
    static ItemLine getItemLine() {
            System.out.println("Enter itemline ID:");
            Integer itemlineId = scanner.nextInt();
            for (int i = 0; i < itemlineList.size(); i++) {
                ItemLine itemLine = itemlineList.get(i);
                if (itemLine.id.equals(itemlineId)) {
                    return itemLine;
                }
            }
            System.out.println("Itemline not found");
            return null;
        }
    }

