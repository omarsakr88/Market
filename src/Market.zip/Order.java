import java.util.ArrayList;
import java.util.Scanner;

public class Order extends BaseObject{

    Integer number;
    Item item;
    static ArrayList<ItemLine> itemlineList;
    ArrayList<Customer> customers = new ArrayList<>();

    void fillNumber() {
        System.out.println("Enter order number:");
        Scanner scanner = new Scanner(System.in);
        number = scanner.nextInt();
    }

    void print() {
        System.out.print("ID");
        System.out.println(id);
        System.out.print("Number");
        System.out.println(number);
        if (item != null) {
            System.out.print("Item:");
            System.out.println(item.name);
        }
        System.out.println("Customers:");
        for (int i = 0; i < customers.size(); i++) {
            Customer customer = customers.get(i);
            System.out.print("ID:");
            System.out.println(customer.id);
            System.out.print("Name:");
            System.out.println(customer.name);
        }
    }


}
