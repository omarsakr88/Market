import java.util.ArrayList;
import java.util.Scanner;

public class Customer extends BaseObject{

    String name;
    String address;
    ArrayList<Order> orderList = new ArrayList<>();


    void fillName() {
        System.out.println("Enter customer name:");
        Scanner scanner = new Scanner(System.in);
        name = scanner.next();
    }
    void fillAdress() {
        System.out.println("Enter customer address:");
        Scanner scanner = new Scanner(System.in);
        name = scanner.next();
    }


    void printChecks() {
        System.out.println("Checks:");
        for (int i = 0; i < orderList.size(); i++) {
            Order order = orderList.get(i);
            order.print();
        }
    }

    void print() {
        System.out.print("ID:");
        System.out.println(id);
        System.out.print("Name:");
        System.out.println(name);
        System.out.print("Address:");
        System.out.println(address);
    }

    Order getOrder() {
        System.out.println("Enter order ID:");
        Scanner scanner = new Scanner(System.in);
        Integer orderId = scanner.nextInt();
        for (int i = 0; i < orderList.size(); i++) {
            Order order = orderList.get(i);
            if (order.id.equals(orderId)) {
                return order;
            }
        }
        return null;
    }
}
