import java.util.Scanner;

public class ItemLine extends BaseObject{

    Integer count;
    Item item;


    void fillCount() {
        System.out.println("Enter count:");
        Scanner scanner = new Scanner(System.in);
        count = scanner.nextInt();
    }

    void print() {
        System.out.println("ID:");
        System.out.print(id);
        System.out.println("Count:");
        System.out.println(count);
    }
}
